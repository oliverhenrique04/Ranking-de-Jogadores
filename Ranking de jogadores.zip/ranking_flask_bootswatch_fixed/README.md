# Sistema de Ranking de Jogadores (Flask + Bootswatch)

Gerencia um ranking de jogadores a partir de um arquivo CSV (`nome,nivel,pontuacao`).
- Importa os dados para SQLite.
- Mantém **histórico de listas** (cada upload cria uma lista).
- Mostra um **dashboard** com seleção de listas e **destaque** dos 3 primeiros.
- **Linhas inválidas** são registradas em `erros.log` (na raiz do projeto).

## Requisitos
- Python 3.10+

## Como rodar
```bash
# 1) Criar ambiente
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 2) Instalar dependências
pip install -r requirements.txt

# 3) Executar
export FLASK_APP=app.py          # Windows PowerShell: $env:FLASK_APP="app.py"
flask run                        # ou: python app.py
```

Acesse: http://127.0.0.1:5000

## Formato do CSV
Cabeçalho **exato** (minúsculo):
```
nome,nivel,pontuacao
```
Exemplo:
```
nome,nivel,pontuacao
Alice,10,1234.5
Bob,9,1199
Carol,11,1300
```

Linhas com campos vazios ou tipos inválidos são ignoradas e logadas em `erros.log` com o número da linha e o motivo.

## Observações
- O banco fica em `instance/ranking.db` (criado automaticamente).
- Ordenação do ranking: `pontuacao DESC`, depois `nivel DESC`, depois `nome ASC`.
- Para trocar o tema Bootswatch, altere a URL no `templates/base.html` (ex.: `darkly`, `flatly`, `cosmo`, etc.).
